<?php

include_once '../dbConnection.php';
header('Content-Type: application/json');

$result = mysqli_query($con,"SELECT * FROM quiz;") or die('error');

$count=mysqli_num_rows($result);

if($count>0){
    $return = array();
    while($row = mysqli_fetch_array($result)) {
        array_push($return , array('eid' => $row['eid'],
            'title' => $row['title'],
            'sahi' => $row['sahi'],
            'wrong' => $row['wrong'],
            'total' => $row['total'],
            'time' => $row['time'],
            'intro' => $row['intro']
        ));
    }
    echo json_encode($return);
    die();
}
die('error');

?>