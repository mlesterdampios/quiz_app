<head>
	<meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Home - Computer Aided Instruction for Philippine Heroes</title>
	<link rel="icon" href="assets/logo/logoshit.png" type="image/gif" sizes="16x16">

	<!-- Libraries -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<script src="assets/js/jquery-3.3.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap-dialogs.js"></script>
    <script type="text/javascript">
    	var appDialog = new BootstrapDialog({
	        preloaderClass: 'bg-dark',
	        buttonClass: 'btn-dark',
	        dialogTitleTag: 'h4',
	        dialogSize: '',
	        animation: true
	    });
    </script>
</head>